#!/usr/bin/python
#-*- coding:utf-8 -*-

from django.contrib import admin
from engine.models import Twitter

class TwitterAdmin(admin.ModelAdmin):
    list_display = ['id','content','author','date']
    list_per_page = 1
    search_fields = ['id','author','date']
    list_filter = ['id','content','author','date']

admin.site.register(Twitter,TwitterAdmin)
