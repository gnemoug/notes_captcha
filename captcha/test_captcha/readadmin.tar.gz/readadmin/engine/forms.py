#!/usr/bin/python
#-*- coding:utf-8 -*-

from django import forms
from captcha.fields import CaptchaField

class CaptchaTestForm(forms.Form):
    myfield = forms.BooleanField(widget=forms.HiddenInput, initial=1)
    captcha = CaptchaField()
