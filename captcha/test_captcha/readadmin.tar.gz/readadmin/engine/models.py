#!/usr/bin/python
#-*- coding:utf-8 -*-

from django.contrib.auth.models import User
from django.db import models
import datetime

class Twitter(models.Model):
    content = models.TextField(u"内容",max_length = 1024)
    author = models.OneToOneField(User,verbose_name = u"作者",related_name = "twitter_author",blank = True,null = True)
    date = models.DateField(u"发表日期",default = datetime.datetime.now,blank = True,null = True)
    reply = models.ForeignKey('self',related_name = "twitter_reply",verbose_name = "回复",blank = True,null = True,default = 0)

    def __unicode__(self):
        return self.content
        
    class Meta:
        db_table = u"twitter"
        verbose_name_plural = '碎语'
