#!/usr/bin/python
#-*- coding:utf-8 -*-

from engine.forms import CaptchaTestForm
from django.shortcuts import render_to_response

def testview(request):
    if request.POST:
        form = CaptchaTestForm(request.POST)
        if form.is_valid():
            human = True
        return render_to_response('yes.html',locals())
    else:
        form = CaptchaTestForm()

    return render_to_response('template.html',locals())
